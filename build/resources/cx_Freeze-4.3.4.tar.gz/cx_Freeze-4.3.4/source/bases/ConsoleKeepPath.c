//-----------------------------------------------------------------------------
// ConsoleKeepPath.c
//   Main routine for frozen programs which need a Python installation to do
// their work.
//-----------------------------------------------------------------------------

#define CX_FREEZE_KEEP_PATH
#include "Console.c"

