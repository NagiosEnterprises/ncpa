cx_PyGenLib
-----------

This project contains a number of generic Python modules that are used by a
number of other projects (cx_OracleTools, cx_OracleDBATools, etc.) and as such
they are handled independently, rather than bundled with the distribution of
the other projects.

It is released under a free software license, see LICENSE.txt for more
details.

